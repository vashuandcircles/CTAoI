<?php echo $__env->make('admin.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="row">
                <h6 class="m-3 font-weight-bold text-primary">Coachings</h6>
                <a href="<?php echo e(url('/addcoachingpage')); ?>" class="m-2 ml-auto btn btn-primary text-white">
                    Add Coaching
                </a>
            </div>
        </div>
        <?php if(session('status')): ?>
        <div class="alert alert-success mt-2 ml-2 mr-2" role="alert">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Director's Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $coachings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if ($row->verified) { ?>
                            <tr>
                                <td><img src="<?php echo e($row->imgpath); ?>" style="width: 50px; height: 75px; object-fit: cover;"> </td>
                                <td><?php echo e($row->name); ?></td>
                                <td><?php echo e($row->directorname); ?></td>
                                <td><?php echo e($row->phone); ?> <br> <?php echo e($row->altphone); ?> </td>
                                <td><?php echo e($row->email); ?></td>
                                <td><?php echo e($row->address1); ?> <?php echo e($row->address2); ?>, <?php echo e($row->state); ?>, <?php echo e($row->city); ?> <?php echo e($row->zipcode); ?></td>
                                <td>
                                    <div class="row">
                                        <?php if (!$row->is_featured) { ?>
                                            <form action="/coaching-feature/<?php echo e($row->id); ?>" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('PUT')); ?>

                                                <button type="submit" href="" class="btn btn-success m-1">Feature</button>
                                            </form>
                                        <?php } ?>
                                        <a href="/coaching-edit/<?php echo e($row->id); ?>" class="btn btn-secondary m-1">Edit</a>
                                        <form action="/coaching-delete/<?php echo e($row->id); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type="submit" href="" class="btn btn-danger m-1">Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('admin.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vijay\Desktop\ctaoi\resources\views/admin/coaching/coachingpage.blade.php ENDPATH**/ ?>