<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="popular_courses">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5">
                <div class="main_title">
                    <h2 class="mb-3">Our Popular Coachings</h2>
                    <p>
                        Replenish man have thing gathering lights yielding shall you
                    </p>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $coachings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if ($row->verified && $row->active) { ?>
                <div class="col-lg-3 mb-4">
                    <div class="single_course">
                        <div class="course_head">
                            <img class="img-fluid" src="<?php echo e($row->imgpath); ?>" style="height: 300px; object-fit: cover;" alt="" />
                        </div>
                        <div class="course_content">
                            <h4 class="mb-3">
                                <a><?php echo e($row->name); ?></a>
                            </h4>
                            <h6>
                                Expert in : <?php echo e($row->specialization); ?>

                            </h6>
                            <?php if($row->level): ?>
                            <h6>
                                Level : <?php echo e($row->level); ?>

                            </h6>
                            <?php endif; ?>
                            <h6>
                                Contact : <?php echo e($row->phone); ?>

                            </h6>
                            <h6 style="word-wrap: break-word;">
                                Email : <?php echo e($row->email); ?>

                            </h6>
                            <h6>
                                Director : <?php echo e($row->directorname); ?>

                            </h6>
                            <h6>
                                Address : <?php if($row->address1 != $row->city): ?> <?php echo e($row->address1); ?>,<?php endif; ?> <?php if($row->address2): ?> <?php echo e($row->address2); ?>, <?php endif; ?> <?php echo e($row->city); ?>, <?php echo e($row->state); ?>

                            </h6>
                        </div>
                    </div>
                <?php } ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="d-flex justify-content-center">
            <?php echo $coachings->links(); ?>

        </div>
    </div>
</div>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vijay\Desktop\andCircles\ctaoi\resources\views/coachings.blade.php ENDPATH**/ ?>